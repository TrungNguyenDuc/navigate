"""
API for Hamamatsu Cameras.
"""