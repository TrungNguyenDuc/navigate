"""
API for Photometrics cameras.
"""